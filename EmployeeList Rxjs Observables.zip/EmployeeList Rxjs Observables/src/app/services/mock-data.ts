const mockdata = [{
    "id": 1,
    "employee_name": "Vitia",
    "employee_salary": 6133,
    "employee_age": 45,
    "profile_image": "http://dummyimage.com/226x100.png/dddddd/000000"
  }, {
    "id": 2,
    "employee_name": "Moses",
    "employee_salary": 8185,
    "employee_age": 27,
    "profile_image": "http://dummyimage.com/157x100.png/cc0000/ffffff"
  }, {
    "id": 3,
    "employee_name": "Verla",
    "employee_salary": 5617,
    "employee_age": 49,
    "profile_image": "http://dummyimage.com/210x100.png/dddddd/000000"
  }, {
    "id": 4,
    "employee_name": "Linus",
    "employee_salary": 4672,
    "employee_age": 38,
    "profile_image": "http://dummyimage.com/146x100.png/5fa2dd/ffffff"
  }, {
    "id": 5,
    "employee_name": "Barby",
    "employee_salary": 4163,
    "employee_age": 35,
    "profile_image": "http://dummyimage.com/180x100.png/cc0000/ffffff"
  }]
export default mockdata;