import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import IEmployee from '../interface/employee2';

import MockProductsData from "./mock-data"

import { from, of , throwError , interval ,merge, Observable } from "rxjs"
import  { mapTo , map , find , take , filter, catchError} from "rxjs/operators"

@Injectable({
  providedIn: 'root'
})
export class EmpServiceService {

  constructor(private http:HttpClient) { }
  employeeList : IEmployee[] = [];
   getService() {
  //   //return this.http.get("http://dummy.restapiexample.com/api/v1/employees")
  return this.http.get<IEmployee[]>("http://localhost:4500/employees")
  //   return this.http.get<IEmployee[]>("http://dummy.restapiexample.com/api/v1/employees")

  //   //   from(MockProductsData).subscribe((data)=>{
  //   //   console.log(data, "from observable")
  //   // })
  //   //  return of(MockProductsData)
    
     from(MockProductsData).subscribe((data)=>{
      console.log(data, "from observable")
    })
     return of(MockProductsData)
  }
  public getEmployees(): Observable<IEmployee[]> 
  {
    const url = 'http://dummy.restapiexample.com/api/v1/employees';
 
    return this.http.get<IEmployee[]>(url);
  }
}
